-- =====================================================
-- DA Healthcare Project | Step 4: KPI queries (MySQL 8)
-- Run one query at a time: click inside it, press Ctrl+Enter
-- Default scope = Comparable (standard acute-care) hospitals,
-- because Kaiser reports revenue through two regional records.
-- =====================================================
USE healthcare_data;

-- ---------- Row-count check (QA) ----------
SELECT 'hospital_quarterly' AS table_name, COUNT(*) AS row_count,
       COUNT(DISTINCT FAC_NO) AS hospitals, COUNT(DISTINCT PERIOD) AS quarters
FROM hospital_quarterly
UNION ALL
SELECT 'hospital_payer', COUNT(*), COUNT(DISTINCT FAC_NO), COUNT(DISTINCT PERIOD) FROM hospital_payer;

-- =====================================================
-- KPI 1-10: headline cards (Comparable hospitals, all quarters)
-- =====================================================
SELECT
  ROUND(SUM(GRIP_TOT + GROP_TOT)/1e9, 2)                       AS KPI01_Gross_Patient_Revenue_Bn,
  ROUND(SUM(NET_TOT)/1e9, 2)                                   AS KPI02_Net_Patient_Revenue_Bn,
  ROUND(SUM(NET_TOT + OTH_OP_REV)/1e9, 2)                      AS KPI03_Total_Operating_Revenue_Bn,
  ROUND(SUM(TOT_OP_EXP)/1e9, 2)                                AS KPI04_Operating_Expenses_Bn,
  ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)/1e9, 2)         AS KPI05_Operating_Result_Bn,
  ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)
        / SUM(NET_TOT + OTH_OP_REV) * 100, 2)                  AS KPI06_Operating_Margin_Pct,
  ROUND(SUM(NET_TOT) / SUM(GRIP_TOT + GROP_TOT) * 100, 2)      AS KPI07_Net_to_Gross_Pct,
  ROUND(SUM(CAP_EXP)/1e9, 2)                                   AS KPI08_Capital_Expenditure_Bn,
  SUM(DIS_TOT)                                                 AS KPI09_Discharges,
  COUNT(DISTINCT FAC_NO)                                       AS KPI10_Hospitals
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable';

-- Same KPIs for every hospital type (shows the Kaiser effect)
SELECT TYPE_HOSP,
       COUNT(DISTINCT FAC_NO)                                  AS Hospitals,
       ROUND(SUM(NET_TOT)/1e9, 2)                              AS Net_Revenue_Bn,
       ROUND(SUM(TOT_OP_EXP)/1e9, 2)                           AS Operating_Expenses_Bn,
       ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)
             / NULLIF(SUM(NET_TOT + OTH_OP_REV), 0) * 100, 2)  AS Operating_Margin_Pct
FROM hospital_quarterly
GROUP BY TYPE_HOSP
ORDER BY Net_Revenue_Bn DESC;

-- =====================================================
-- KPI 11: Top 10 hospitals by net patient revenue
-- =====================================================
SELECT HOSPITAL, COUNTY_NAME,
       ROUND(SUM(NET_TOT)/1e6, 1)                              AS Net_Revenue_Mn,
       ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)
             / NULLIF(SUM(NET_TOT + OTH_OP_REV), 0) * 100, 2)  AS Operating_Margin_Pct
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable'
GROUP BY FAC_NO, HOSPITAL, COUNTY_NAME
ORDER BY SUM(NET_TOT) DESC
LIMIT 10;

-- =====================================================
-- KPI 12: Operating expenses vs operating revenue by hospital
--         (10 largest operating losses)
-- =====================================================
SELECT HOSPITAL,
       ROUND(SUM(NET_TOT + OTH_OP_REV)/1e6, 1)                 AS Operating_Revenue_Mn,
       ROUND(SUM(TOT_OP_EXP)/1e6, 1)                           AS Operating_Expenses_Mn,
       ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)/1e6, 1)    AS Operating_Result_Mn
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable'
GROUP BY FAC_NO, HOSPITAL
ORDER BY Operating_Result_Mn ASC
LIMIT 10;

-- =====================================================
-- KPI 13: Hospitals by county (map)
-- =====================================================
SELECT COUNTY_NAME,
       COUNT(DISTINCT FAC_NO)                                  AS Hospitals,
       SUM(DIS_TOT)                                            AS Discharges,
       ROUND(SUM(NET_TOT)/1e9, 2)                              AS Net_Revenue_Bn,
       ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)
             / NULLIF(SUM(NET_TOT + OTH_OP_REV), 0) * 100, 2)  AS Operating_Margin_Pct
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable'
GROUP BY COUNTY_NAME
ORDER BY Net_Revenue_Bn DESC;

-- =====================================================
-- KPI 14: Discharges and net revenue by payer (share of total)
-- =====================================================
SELECT PAYER,
       SUM(DISCHARGES)                                         AS Discharges,
       ROUND(SUM(DISCHARGES) * 100 / SUM(SUM(DISCHARGES)) OVER (), 1)   AS Discharge_Share_Pct,
       ROUND(SUM(NET_REVENUE)/1e9, 1)                          AS Net_Revenue_Bn,
       ROUND(SUM(NET_REVENUE) * 100 / SUM(SUM(NET_REVENUE)) OVER (), 1) AS Revenue_Share_Pct
FROM hospital_payer
WHERE TYPE_HOSP = 'Comparable'
GROUP BY PAYER
ORDER BY Net_Revenue_Bn DESC;

-- Payer discharges by quarter (stacked bar)
SELECT PERIOD,
       SUM(CASE WHEN PAYER = 'Medicare'    THEN DISCHARGES END) AS Medicare,
       SUM(CASE WHEN PAYER = 'Medi-Cal'    THEN DISCHARGES END) AS Medi_Cal,
       SUM(CASE WHEN PAYER = 'Third Party' THEN DISCHARGES END) AS Third_Party,
       SUM(CASE WHEN PAYER = 'Other'       THEN DISCHARGES END) AS Other
FROM hospital_payer
WHERE TYPE_HOSP = 'Comparable'
GROUP BY PERIOD
ORDER BY PERIOD;

-- =====================================================
-- KPI 15: Available beds vs net patient revenue (scatter)
-- =====================================================
SELECT HOSPITAL, ROUND(AVG(AVL_BEDS)) AS Avg_Available_Beds,
       ROUND(SUM(NET_TOT)/1e6, 1)     AS Net_Revenue_Mn
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable'
GROUP BY FAC_NO, HOSPITAL
ORDER BY Avg_Available_Beds DESC;

-- =====================================================
-- KPI 16: Hospital table (latest quarter, 2020-Q2)
-- =====================================================
SELECT HOSPITAL, COUNTY_NAME, STF_BEDS, DIS_TOT, NET_TOT,
       ROUND(OPER_MARGIN_PCT * 100, 2) AS Operating_Margin_Pct
FROM hospital_quarterly
WHERE PERIOD = '2020-Q2' AND TYPE_HOSP = 'Comparable'
ORDER BY NET_TOT DESC;

-- =====================================================
-- KPI 17: Quarterly trend and quarter-on-quarter change (window function)
-- =====================================================
WITH q AS (
  SELECT PERIOD,
         SUM(NET_TOT + OTH_OP_REV)               AS Op_Revenue,
         SUM(TOT_OP_EXP)                         AS Op_Expenses,
         SUM(DIS_TOT)                            AS Discharges
  FROM hospital_quarterly
  WHERE TYPE_HOSP = 'Comparable'
  GROUP BY PERIOD
)
SELECT PERIOD,
       ROUND(Op_Revenue/1e9, 2)                                AS Op_Revenue_Bn,
       ROUND(Op_Expenses/1e9, 2)                               AS Op_Expenses_Bn,
       ROUND((Op_Revenue - Op_Expenses) / Op_Revenue * 100, 2) AS Operating_Margin_Pct,
       Discharges,
       ROUND((Discharges - LAG(Discharges) OVER (ORDER BY PERIOD))
             / LAG(Discharges) OVER (ORDER BY PERIOD) * 100, 1) AS Discharges_QoQ_Pct
FROM q
ORDER BY PERIOD;

-- Ownership comparison
SELECT TYPE_CNTRL, COUNT(DISTINCT FAC_NO) AS Hospitals,
       ROUND(SUM(NET_TOT + OTH_OP_REV - TOT_OP_EXP)
             / SUM(NET_TOT + OTH_OP_REV) * 100, 2)             AS Operating_Margin_Pct
FROM hospital_quarterly
WHERE TYPE_HOSP = 'Comparable'
GROUP BY TYPE_CNTRL
ORDER BY Operating_Margin_Pct DESC;
